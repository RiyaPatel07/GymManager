﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymManager.Dtos
{
    public class AreaDto
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}