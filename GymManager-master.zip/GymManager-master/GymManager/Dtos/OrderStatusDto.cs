﻿namespace GymManager.Dtos
{
    public class OrderStatusDto
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}