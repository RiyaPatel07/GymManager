﻿using System.Web.Mvc;

namespace GymManager.Controllers
{
    public class FlavorsController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
    }
}