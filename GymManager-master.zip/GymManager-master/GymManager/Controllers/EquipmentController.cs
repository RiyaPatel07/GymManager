﻿using System.Web.Mvc;

namespace GymManager.Controllers
{
    public class EquipmentController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }

        public ViewResult New()
        {
            return View();
        }        
        
        public ViewResult Edit()
        {
            return View();
        }
    }
}